function f=matleap_frame
% MATLEAP_FRAME Get a frame from the leap motion controller
f=matleap(1);
